---

kanban-plugin: basic

---

## To-do



## Done

- [x] 作运动 ✅ 2022-07-31




%% kanban:settings
```
{"kanban-plugin":"basic","show-checkboxes":true,"show-relative-date":true,"link-date-to-daily-note":true,"lane-width":300}
```
%%