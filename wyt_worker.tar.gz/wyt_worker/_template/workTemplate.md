---
date: {{DATE:YYYY-MM-DD-dddd HH:mm:ss}}
update: 2022-07-30-Saturday 23:58:23
tags: [work]
id: work{{DATE:YYYYMMDDHHmmss}}
banner: "![[astrowalk.gif]]"
---

> [!todo]
> ```tasks
not done
description does not include #check
path does not include _template


## 今日计划

### 上午计划

- [ ] 书写工作计划

### 下午计划
- [ ] 书写工作计划

### 晚上计划
- [ ] 书写工作计划 


### 明日计划

- [ ] 15:00 书写明日工作计划

### 今日总结


